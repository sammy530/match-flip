function createNewCard() {
  const cardElement = document.createElement("div");
  cardElement.className = "card";

  const cardDown = document.createElement("div");
  cardDown.className = "card-down";

  const cardUp = document.createElement("div");
  cardUp.className = "card-up";

  cardElement.appendChild(cardDown);
  cardElement.appendChild(cardUp);
  return cardElement;
}

function appendNewCard(parentElement) {
  const cardElement = createNewCard();
  parentElement.appendChild(cardElement);
  return cardElement;
}

function shuffleCardImageClasses() {
  const imageClasses = [
    "image-1",
    "image-1",
    "image-2",
    "image-2",
    "image-3",
    "image-3",
    "image-4",
    "image-4",
    "image-5",
    "image-5",
    "image-6",
    "image-6",
  ];
  return _.shuffle(imageClasses);
}

function createCards(parentElement, shuffledImageClasses) {
  const cardObjects = [];
  for (let i = 0; i < 12; i++) {
    const cardElement = appendNewCard(parentElement);
    cardElement.classList.add(shuffledImageClasses[i]);
    cardObjects.push({
      index: i,
      element: cardElement,
      imageClass: shuffledImageClasses[i],
    });
  }
  return cardObjects;
}

function doCardsMatch(cardObject1, cardObject2) {
  return cardObject1.imageClass === cardObject2.imageClass;
}

let counters = {};

function incrementCounter(counterName, parentElement) {
  if (counters[counterName] === undefined) {
    counters[counterName] = 0;
  }
  counters[counterName]++;
  parentElement.innerText = counters[counterName];
}

let lastCardFlipped = null;

function onCardFlipped(newlyFlippedCard) {
  incrementCounter("flips", document.getElementById("flip-count"));

  if (lastCardFlipped === null) {
    lastCardFlipped = newlyFlippedCard;
    return;
  }

  if (doCardsMatch(lastCardFlipped, newlyFlippedCard)) {
    incrementCounter("matches", document.getElementById("match-count"));


    lastCardFlipped.element.classList.add("matched");
    newlyFlippedCard.element.classList.add("matched");


    if (counters["matches"] === 6) {
   
      winAudio.play();
    } else {
      matchAudio.play();
    }

    lastCardFlipped = null;
  } else {
    setTimeout(() => {
      newlyFlippedCard.element.classList.remove("flipped");
      lastCardFlipped.element.classList.remove("flipped");
      lastCardFlipped = null;
    }, 1000);
  }
}

function resetGame() {
  const cardContainer = document.getElementById("card-container");
  while (cardContainer.firstChild) {
    cardContainer.removeChild(cardContainer.firstChild);
  }

  document.getElementById("flip-count").innerText = "0";
  document.getElementById("match-count").innerText = "0";

  counters = {};
  lastCardFlipped = null;

  setUpGame();
}

// Set up the game
setUpGame();
